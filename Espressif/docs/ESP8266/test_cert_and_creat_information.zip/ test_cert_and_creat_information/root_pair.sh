mkdir /root/ca
cd /root/ca

mkdir -p certs crl csr newcerts private
chmod 700 private
touch index.txt
echo 1000 > serial
echo 1000 > /home/genmisc/software_output/liuhan/root/ca/intermediate/crlnumber

#Create the root key(ca.key.pem)
cd /home/genmisc/software_output/liuhan/root/ca
openssl genrsa -aes256 -out /home/genmisc/software_output/liuhan/root/ca/private/ca.key.pem 4096

chmod 400 /home/genmisc/software_output/liuhan/root/ca/private/ca.key.pem

#Use the root key(ca.key.pem) to create a root certificate(ca.cert.pem)
cd /home/genmisc/software_output/liuhan/root/ca
openssl req -config /home/genmisc/software_output/liuhan/root/ca/openssl.cnf	\
	-key /home/genmisc/software_output/liuhan/root/ca/private/ca.key.pem \
        -new -x509 -days 7300 -sha256 -extensions v3_ca \
        -out /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem

chmod 444 /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem

#Verify the certificate -- The Issuer and Subject are identical as the certificate is self-signed.
openssl x509 -noout -text \
      -in  /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem
 
# convert certificate into DER format 
openssl x509 -in /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem -outform DER -out /home/genmisc/software_output/liuhan/root/ca/certs/TLS.root.cer

#config infomation
Enter pass phrase for ca.key.pem: secretpassword
You are about to be asked to enter information that will be incorporated
into your certificate request.
-----
Country Name (2 letter code) [XX]:GB
State or Province Name []:England
Locality Name []:
Organization Name []:Alice Ltd
Organizational Unit Name []:Alice Ltd Certificate Authority
Common Name []:Alice Ltd Root CA
Email Address []: