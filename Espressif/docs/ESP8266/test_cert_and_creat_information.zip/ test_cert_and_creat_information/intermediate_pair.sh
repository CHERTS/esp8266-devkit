mkdir /root/ca/intermediate
cd /root/ca/intermediate
mkdir -p certs crl csr newcerts private
chmod 700 private
touch index.txt
echo 1000 > serial
echo 1000 > /home/genmisc/software_output/liuhan/root/ca/intermediate/crlnumber

#Create the intermediate key
cd  /home/genmisc/software_output/liuhan/root/ca
openssl genrsa -aes256 -out /home/genmisc/software_output/liuhan/root/ca/intermediate/private/intermediate.key.pem 4096

chmod 400 /home/genmisc/software_output/liuhan/root/ca/intermediate/private/intermediate.key.pem

#Use the intermediate key to create a certificate signing request
#The details should generally match the root CA, except the Common Name which must be different.
cd  /home/genmisc/software_output/liuhan/root/ca
openssl req -config /home/genmisc/software_output/liuhan/root/ca/intermediate/openssl.cnf -new -sha256 \
      -key /home/genmisc/software_output/liuhan/root/ca/intermediate/private/intermediate.key.pem \
      -out /home/genmisc/software_output/liuhan/root/ca/intermediate/csr/intermediate.csr.pem

#To create an intermediate certificate, use the root CA with the v3_intermediate_ca extension to sign the intermediate CSR. 
cd  /home/genmisc/software_output/liuhan/root/ca
openssl ca -config /home/genmisc/software_output/liuhan/root/ca/openssl.cnf -extensions v3_intermediate_ca \
      -days 3650 -notext -md sha256 \
      -in /home/genmisc/software_output/liuhan/root/ca/intermediate/csr/intermediate.csr.pem \
      -out /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem

chmod 444 /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem

#Verify the certificate -- The Issuer is the root CA
openssl x509 -noout -text \
      -in  /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem

#Use the CA certificate chain file (ca.cert.pem) to verify that the new certificate has a valid chain of trust.
openssl verify -CAfile /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem \
      /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem

#Create the certificate chain file
#When an application tries to verify a certificate signed by the intermediate CA,
#it must also verify the intermediate certificate against the root certificate.
cat /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem \
      /home/genmisc/software_output/liuhan/root/ca/certs/ca.cert.pem > /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/ca-chain.cert.pem

chmod 444 /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/ca-chain.cert.pem

# convert certificate into DER format
openssl x509 -in /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/intermediate.cert.pem \
-outform DER -out /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/TLS.intermediate.cer

openssl x509 -in /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/ca-chain.cert.pem \
-outform DER -out /home/genmisc/software_output/liuhan/root/ca/intermediate/certs/TLS.ca-chain.cer

#config infomation
Enter pass phrase for intermediate.key.pem: secretpassword
You are about to be asked to enter information that will be incorporated
into your certificate request.
-----
Country Name (2 letter code) [XX]:GB
State or Province Name []:England
Locality Name []:
Organization Name []:Alice Ltd
Organizational Unit Name []:Alice Ltd Certificate Authority
Common Name []:Alice Ltd Intermediate CA
Email Address []: